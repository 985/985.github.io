//
//  ydcbAppDelegate.h
//  ydcb
//
//  Created by Tommy Su on 11-9-12.
//  Copyright 2011年 njucs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ydcbAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
