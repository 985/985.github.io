//
//  MainMenuViewController.h
//  ydcb
//
//  Created by Tommy Su on 11-9-12.
//  Copyright 2011年 njucs. All rights reserved.
//

#define BUTTONCOUNT 9

@interface MainMenuViewController : UIViewController {
    UIScrollView *mainMenuScrollView;
}


@property (nonatomic, retain) IBOutlet UIScrollView *mainMenuScrollView;

- (IBAction)changeView:(id)sender;


@end
