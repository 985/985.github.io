//
//  test.h
//  ydcb
//
//  Created by Sun Wenxiang on 11-9-21.
//  Copyright 2011年 njucs. All rights reserved.
//

@interface testViewController : UIViewController{
    UIScrollView *testScrollView;
    UITextField *textfield1;
    UITextField *textfield2;
    UITextField *textfield3;
    UITextField *textfield4;
    UITextField *textfield5;
    UITextView *textview;
    UIControl *myview;
}

@end