//
//  NewsClueViewController.m
//  ydcb
//
//  Created by Tommy Su on 11-9-12.
//  Copyright 2011年 njucs. All rights reserved.
//

#import "NewsClueViewController.h"

#import <QuartzCore/QuartzCore.h>
@implementation NewsClueViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle



- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title = @"新闻线索";
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackTranslucent;
    
    NSMutableArray *titleArray = [[NSMutableArray alloc] initWithObjects:@"开始时间:", @"结束时间:", @"标      题:", @"类      别:", @"状      态:",@"内      容:", nil];
    
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
    NSUInteger pageNum = ([titleArray count] - 2) / 5 + 1;
    
    NewsClueScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    NewsClueScrollView.contentSize = CGSizeMake(320, 700*pageNum);
    [self.view addSubview:NewsClueScrollView];
    
    
    myview=[[UIControl alloc] initWithFrame:CGRectMake(0, -30, 320, 680*pageNum+50)];
    [myview setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]]];
    [myview addTarget:self action:@selector(remove) forControlEvents:UIControlEventTouchDown];
    [NewsClueScrollView addSubview:myview];
    [myview release];
    
    
    /*UIButton *mybtn=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 320, 800)];
     [mybtn setBackgroundColor:[UIColor clearColor]];
     [mybtn addTarget:self action:@selector(remove) forControlEvents:UIControlEventTouchDown];
     [testScrollView addSubview:mybtn];
     [mybtn release];*/
    
    textfield1 = [[UITextField alloc] initWithFrame:CGRectMake(130, 70, 160, 30)];
    [textfield1 setBackgroundColor:[UIColor whiteColor]];
    //[textfield1 setKeyboardType:(UIKeyboardTypeDecimalPad)];
    /*边框*/
    textfield1.layer.cornerRadius=4;
    textfield1.layer.masksToBounds=YES;
    textfield1.layer.borderWidth=2;
    textfield1.layer.borderColor=[[UIColor colorWithRed:0.25 green:0.25 blue:0.25 alpha:1] CGColor];
    /*阴影
     textfield1.layer.shadowOffset=CGSizeMake(1, 1);
     textfield1.layer.shadowColor=[[UIColor blackColor] CGColor];
     textfield1.layer.shadowOpacity=5;
     textfield1.layer.shadowRadius=1;*/
    [NewsClueScrollView addSubview:textfield1];
    [textfield1 release];
    
    textfield2 = [[UITextField alloc] initWithFrame:CGRectMake(130, 115, 160, 30)];
    [textfield2 setBackgroundColor:[UIColor whiteColor]];
    //[textfield2 setKeyboardType:(UIKeyboardTypeDecimalPad)];
    /*边框*/
    textfield2.layer.cornerRadius=4;
    textfield2.layer.masksToBounds=YES;
    textfield2.layer.borderWidth=2;
    textfield2.layer.borderColor=[[UIColor colorWithRed:0.25 green:0.25 blue:0.25 alpha:1] CGColor];
    /*阴影
     textfield2.layer.shadowOffset=CGSizeMake(1, 1);
     textfield2.layer.shadowColor=[[UIColor blackColor] CGColor];
     textfield2.layer.shadowOpacity=5;
     textfield2.layer.shadowRadius=1;*/
    [NewsClueScrollView addSubview:textfield2];
    [textfield2 release];
    
    textfield3 = [[UITextField alloc] initWithFrame:CGRectMake(130, 160, 160, 30)];
    [textfield3 setBackgroundColor:[UIColor whiteColor]];
    //[textfield3 setKeyboardType:(UIKeyboardTypeDecimalPad)];
    /*边框*/
    textfield3.layer.cornerRadius=4;
    textfield3.layer.masksToBounds=YES;
    textfield3.layer.borderWidth=2;
    textfield3.layer.borderColor=[[UIColor colorWithRed:0.25 green:0.25 blue:0.25 alpha:1] CGColor];
    /*阴影
     textfield3.layer.shadowOffset=CGSizeMake(1, 1);
     textfield3.layer.shadowColor=[[UIColor blackColor] CGColor];
     textfield3.layer.shadowOpacity=5;
     textfield3.layer.shadowRadius=1;*/
    [NewsClueScrollView addSubview:textfield3];
    [textfield3 release];
    
    textfield4 = [[UITextField alloc] initWithFrame:CGRectMake(130, 205, 160, 30)];
    [textfield4 setBackgroundColor:[UIColor whiteColor]];
    //[textfield4 setKeyboardType:(UIKeyboardTypeDecimalPad)];
    /*边框*/
    textfield4.layer.cornerRadius=4;
    textfield4.layer.masksToBounds=YES;
    textfield4.layer.borderWidth=2;
    textfield4.layer.borderColor=[[UIColor colorWithRed:0.25 green:0.25 blue:0.25 alpha:1] CGColor];
    /*阴影
     textfield4.layer.shadowOffset=CGSizeMake(1, 1);
     textfield4.layer.shadowColor=[[UIColor blackColor] CGColor];
     textfield4.layer.shadowOpacity=5;
     textfield4.layer.shadowRadius=1;*/
    [NewsClueScrollView addSubview:textfield4];
    [textfield4 release];
    
    textfield5 = [[UITextField alloc] initWithFrame:CGRectMake(130, 250, 160, 30)];
    [textfield5 setBackgroundColor:[UIColor whiteColor]];
    //[textfield5 setKeyboardType:(UIKeyboardTypeDecimalPad)];
    /*边框*/
    textfield5.layer.cornerRadius=4;
    textfield5.layer.masksToBounds=YES;
    textfield5.layer.borderWidth=2;
    textfield5.layer.borderColor=[[UIColor colorWithRed:0.25 green:0.25 blue:0.25 alpha:1] CGColor];
    /*阴影
     textfield5.layer.shadowOffset=CGSizeMake(1, 1);
     textfield5.layer.shadowColor=[[UIColor blackColor] CGColor];
     textfield5.layer.shadowOpacity=5;
     textfield5.layer.shadowRadius=1;*/
    [NewsClueScrollView addSubview:textfield5];
    [textfield5 release];
    
    textview = [[UITextView alloc] initWithFrame:CGRectMake(48, 100+225, 243, 150)];
    [textview setBackgroundColor:[UIColor whiteColor]];
    /*边框*/
    textview.layer.cornerRadius=4;
    textview.layer.masksToBounds=YES;
    textview.layer.borderWidth=2;
    textview.layer.borderColor=[[UIColor colorWithRed:0.25 green:0.25 blue:0.25 alpha:1] CGColor];
    /*阴影
     textview.layer.shadowOffset=CGSizeMake(1, 1);
     textview.layer.shadowColor=[[UIColor blackColor] CGColor];
     textview.layer.shadowOpacity=5;
     textview.layer.shadowRadius=1;*/
    [NewsClueScrollView addSubview:textview];
    
    [textview release];
    
    for(int i=0;i<=5;i++){    
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(30,68+i*45, 100, 30)];
        [label setText:[titleArray objectAtIndex:i]];
        [label setBackgroundColor:[UIColor clearColor]];
        [label setTextAlignment:UITextAlignmentCenter];
        [NewsClueScrollView addSubview:label];
        
        [label release];
    }
    //[self.view addSubview:testScrollView];
}

-(void)remove{
	[textfield1 resignFirstResponder];
    [textfield2 resignFirstResponder];
    [textfield3 resignFirstResponder];
    [textfield4 resignFirstResponder];
    [textfield5 resignFirstResponder];
    [textview resignFirstResponder];
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
