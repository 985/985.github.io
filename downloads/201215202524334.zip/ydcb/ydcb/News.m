//
//  News.m
//  ydcb
//
//  Created by Tommy Su on 11-9-14.
//  Copyright 2011年 njucs. All rights reserved.
//

#import "News.h"

@implementation News

@synthesize startTime;
@synthesize endTime;
@synthesize title;
@synthesize type;
@synthesize status;
@synthesize content;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
