//
//  ManuscriptEditingViewController.h
//  ydcb
//
//  Created by Tommy Su on 11-9-12.
//  Copyright 2011年 njucs. All rights reserved.
//



@interface ManuscriptEditingViewController : UIViewController{
    UIScrollView *ManuscriptEditingScrollView;
}

@end
