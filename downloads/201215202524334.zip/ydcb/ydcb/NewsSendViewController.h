//
//  NewsSendViewController.h
//  ydcb
//
//  Created by Tommy Su on 11-9-12.
//  Copyright 2011年 njucs. All rights reserved.
//



@interface NewsSendViewController : UIViewController{
    UIScrollView *NewsSendScrollView;
    UITextField *textfield1;
    UITextField *textfield2;
    UITextField *textfield3;
    UITextField *textfield4;
    UITextField *textfield5;
    UITextView *textview;
    UIControl *myview;
}

@end
