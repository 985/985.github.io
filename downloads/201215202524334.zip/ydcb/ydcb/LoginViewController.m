//
//  LoginViewController.m
//  ydcb
//
//  Created by Tommy Su on 11-9-12.
//  Copyright 2011年 njucs. All rights reserved.
//

#import "LoginViewController.h"
#import "MainMenuViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation LoginViewController





- (IBAction)login:(id)sender {
    if ([usernameTextField.text isEqualToString:@"admin"] && [passwordTextField.text isEqualToString:@"admin"]) {
        MainMenuViewController *mainMenuViewController = [[MainMenuViewController alloc] init];
        UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:mainMenuViewController];
        
        CATransition *mainMenuTransition = [CATransition animation];
        mainMenuTransition.timingFunction = UIViewAnimationCurveEaseInOut;
        mainMenuTransition.duration = 0.4f;
        mainMenuTransition.type = kCATransitionMoveIn;
        mainMenuTransition.subtype = kCATransitionFromTop;
        [self.view.layer addAnimation:mainMenuTransition forKey:nil];
        [self.view addSubview:navigationController.view];
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"登录失败"
                                message:@"用户名密码都是admin"
                                delegate:nil
                                cancelButtonTitle:@"好"
                                otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]]];
    
    myview=[[UIControl alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    [myview setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]]];
    [myview addTarget:self action:@selector(remove) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:myview];
    [myview release];
    
    mynavigationbar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 19, 320, 44)];
    mynavigationbar.barStyle = UIBarStyleBlackTranslucent;
    mynavigationbar.topItem.title = @"test";
    [myview addSubview:mynavigationbar];
    usernameTextField = [[UITextField alloc] initWithFrame:CGRectMake(110, 120, 160, 30)];
    [usernameTextField setBackgroundColor:[UIColor whiteColor]];
    //[usernameTextField setKeyboardType:(UIKeyboardTypeDecimalPad)];
    /*边框*/
    usernameTextField.text=@"admin";
    
    usernameTextField.layer.cornerRadius=4;
    usernameTextField.layer.masksToBounds=YES;
    usernameTextField.layer.borderWidth=2;
    usernameTextField.layer.borderColor=[[UIColor colorWithRed:0.25 green:0.25 blue:0.25 alpha:1] CGColor];
    /*阴影
     usernameTextField.layer.shadowOffset=CGSizeMake(1, 1);
     usernameTextField.layer.shadowColor=[[UIColor blackColor] CGColor];
     usernameTextField.layer.shadowOpacity=5;
     usernameTextField.layer.shadowRadius=1;*/
    [self.view addSubview:usernameTextField];
    [usernameTextField release];
    
    passwordTextField = [[UITextField alloc] initWithFrame:CGRectMake(110, 180, 160, 30)];
    [passwordTextField setBackgroundColor:[UIColor whiteColor]];
    [passwordTextField setSecureTextEntry:(YES)];
    //[passwordTextField setKeyboardType:(UIKeyboardTypeDecimalPad)];
    /*边框*/
    passwordTextField.text=@"admin";
    passwordTextField.layer.cornerRadius=4;
    passwordTextField.layer.masksToBounds=YES;
    passwordTextField.layer.borderWidth=2;
    passwordTextField.layer.borderColor=[[UIColor colorWithRed:0.25 green:0.25 blue:0.25 alpha:1] CGColor];
    /*阴影
     passwordTextField.layer.shadowOffset=CGSizeMake(1, 1);
     passwordTextField.layer.shadowColor=[[UIColor blackColor] CGColor];
     passwordTextField.layer.shadowOpacity=5;
     passwordTextField.layer.shadowRadius=1;*/
    [self.view addSubview:passwordTextField];
    [passwordTextField release];
    
   

    NSMutableArray *titleArray = [[NSMutableArray alloc] initWithObjects:@"用户名:", @"密    码:",nil];
    
    for(int i=0;i<=1;i++){    
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(40,117+i*60, 70, 30)];
        [label setText:[titleArray objectAtIndex:i]];
        [label setBackgroundColor:[UIColor clearColor]];
        [label setTextAlignment:UITextAlignmentCenter];
        [self.view addSubview:label];
        
        [label release];
    } 
    
    
    mybutton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [mybutton setFrame:CGRectMake(110,250,100,40)];
    [mybutton addTarget:self action:@selector(login:) forControlEvents:UIControlEventTouchUpInside];
    mybutton.layer.cornerRadius=4;
    mybutton.layer.masksToBounds=YES;
    mybutton.layer.borderWidth=2;
    mybutton.layer.borderColor=[[UIColor colorWithRed:0.25 green:0.25 blue:0.25 alpha:1] CGColor];
    [self.view addSubview:mybutton];

    // Do any additional setup after loading the view from its nib.
}

-(void)remove{
	[usernameTextField resignFirstResponder];
    [passwordTextField resignFirstResponder];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
