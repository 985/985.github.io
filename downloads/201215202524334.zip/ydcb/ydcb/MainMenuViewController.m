//
//  MainMenuViewController.m
//  ydcb
//
//  Created by Tommy Su on 11-9-12.
//  Copyright 2011年 njucs. All rights reserved.
//

#import "MainMenuViewController.h"
#import <QuartzCore/QuartzCore.h>

//#import "test.h"
#import "NewsClueViewController.h"
#import "NewsSendViewController.h"
#import "ManuscriptEditingViewController.h"
#import "ManuscriptWritingListViewController.h"
#import "RecycleBinViewController.h"

@implementation MainMenuViewController

@synthesize mainMenuScrollView;



- (IBAction)changeView:(id)sender {
    UIButton *currentButton = (UIButton *)sender;
    id viewControllToPush;
    switch (currentButton.tag) {
        case 0:
            viewControllToPush = [[NewsClueViewController alloc] init];
            break;
        case 1:
            viewControllToPush = [[NewsSendViewController alloc] init];
            break;
        case 2:
            viewControllToPush = [[ManuscriptWritingListViewController alloc] init];
            break;
        case 3:
            viewControllToPush = [[ManuscriptEditingViewController alloc] init];
            break;
        case 4:
            viewControllToPush = [[RecycleBinViewController alloc] init];
            break;
        default:
            break;
    }
    
    [self.navigationController pushViewController:viewControllToPush animated:YES];
    [viewControllToPush release];
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"主菜单";
    self.navigationController.navigationBar.barStyle=UIBarStyleBlackTranslucent;
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png" ]]];
    mainMenuScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    NSUInteger pageNum = (BUTTONCOUNT - 1) / 9 + 1;
    mainMenuScrollView.contentSize = CGSizeMake(321*pageNum, 367);
    [self.view addSubview:mainMenuScrollView];
    NSMutableArray *titleArray = [[NSMutableArray alloc] initWithObjects:@"新闻线索", @"新闻派单", @"稿件撰写", @"稿件编辑", @"回收站", nil];
    
    for (NSUInteger i=0; i<[titleArray count]; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [button setFrame:CGRectMake(18+(i%9%3)*105+(i/9)*320, 85+(i%9/3)*135, 80, 80)];
        button.tag = i;
        [button addTarget:self action:@selector(changeView:) forControlEvents:UIControlEventTouchUpInside];
        [mainMenuScrollView addSubview:button];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(18+(i%9%3)*105+(i/9)*320, 165+(i%9/3)*135, 80, 20)];
        [label setText:[titleArray objectAtIndex:i]];
        [label setBackgroundColor:[UIColor clearColor]];
        [label setTextAlignment:UITextAlignmentCenter];
        [mainMenuScrollView addSubview:label];
        
        [label release];
         
    }

}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
