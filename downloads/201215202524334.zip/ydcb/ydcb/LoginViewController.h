//
//  LoginViewController.h
//  ydcb
//
//  Created by Tommy Su on 11-9-12.
//  Copyright 2011年 njucs. All rights reserved.
//



@interface LoginViewController : UINavigationController {
    UITextField *usernameTextField;
    UITextField *passwordTextField;
    UIButton *mybutton;
    UIControl *myview;
    UINavigationBar *mynavigationbar;
}


- (IBAction)login:(id)sender;

@end
