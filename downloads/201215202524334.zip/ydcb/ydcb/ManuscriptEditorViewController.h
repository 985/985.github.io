//
//  ManuscriptEditorViewController.h
//  ydcb
//
//  Created by Tommy Su on 11-9-13.
//  Copyright 2011年 njucs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManuscriptEditorViewController : UIViewController {
    
}

@end
