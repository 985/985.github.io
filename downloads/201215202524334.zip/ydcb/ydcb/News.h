//
//  News.h
//  ydcb
//
//  Created by Tommy Su on 11-9-14.
//  Copyright 2011年 njucs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface News : NSObject {
    NSDate *startTime;
    NSDate *endTime;
    NSString *title;
    NSString *type;
    NSInteger status;
    NSString *content;
}

@property NSDate *startTime;
@property NSDate *endTime;
@property NSString *title;
@property NSString *type;
@property NSInteger status;
@property NSString *content;

@end
